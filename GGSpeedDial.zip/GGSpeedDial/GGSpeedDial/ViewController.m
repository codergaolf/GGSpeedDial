//
//  ViewController.m
//  GGSpeedDial
//
//  Created by 高立发 on 2016/10/21.
//  Copyright © 2016年 GG. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (nonatomic, strong) CAShapeLayer *progressLayer;
@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, strong) UILabel *speedLabel;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor colorWithRed:0.098 green:0.5059 blue:0.8039 alpha:1.0];
    
    //0, 速度label和定时器
    // 显示速度值的label
    [self.view addSubview:self.speedLabel];
    // 计时器
    self.timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(setSpeedProgress) userInfo:nil repeats:YES];

    
    
    //1, 画出内侧的圆弧
    
    //center  中心点（可以理解为圆心）
    //radius  半径
    //startAngle 起始角度
    //endAngle  结束角度
    //clockwise  是否顺时针
    UIBezierPath *circle = [UIBezierPath bezierPathWithArcCenter:self.view.center radius:100 startAngle:-M_PI endAngle:0 clockwise:YES];
    CAShapeLayer *shapeLayer = [CAShapeLayer layer];
    shapeLayer.lineWidth = 5.0f;
    shapeLayer.fillColor = [[UIColor clearColor] CGColor];
    shapeLayer.strokeColor = [[UIColor orangeColor] CGColor];
    shapeLayer.path = circle.CGPath;
    
    [self.view.layer addSublayer: shapeLayer];
    
    //2, 画出外侧的刻度
    
    CGFloat perAngle = M_PI / 50;
    
    for (int i = 0; i < 51; i++) {
        CGFloat startAngle = (-M_PI + perAngle * i);
        CGFloat endAngle = startAngle + perAngle/5;
        
        UIBezierPath *tickPath = [UIBezierPath bezierPathWithArcCenter:self.view.center radius:150 startAngle:startAngle endAngle:endAngle clockwise:YES];
        CAShapeLayer *perLayer = [CAShapeLayer layer];
        
        if (i % 5 == 0) {
            perLayer.strokeColor = [[UIColor brownColor] CGColor];
            perLayer.lineWidth = 10.f;
        } else {
            perLayer.strokeColor = [[UIColor lightGrayColor] CGColor];
            perLayer.lineWidth = 5;
        }
        
        perLayer.path = tickPath.CGPath;
        
        [self.view.layer addSublayer: perLayer];
        
    }
    
    //3, 增加刻度值
    CGFloat textAngel = M_PI / 10;
    for (NSInteger i = 0; i < 11; i++) {
        CGPoint point = [self calculateTextPositonWithArcCenter:self.view.center Angle:textAngel * i];
        NSString *tickText = [NSString stringWithFormat:@"%zd",labs(10 - i) * 10];
        //默认label的大小23 * 14
        UILabel *text = [[UILabel alloc] initWithFrame:CGRectMake(point.x - 8, point.y - 7, 23, 14)];
        text.text = tickText;
        text.font = [UIFont systemFontOfSize:10.f];
        text.textColor = [UIColor colorWithRed:0.54 green:0.78 blue:0.91 alpha:1.0];
        text.textAlignment = NSTextAlignmentLeft;
        [self.view addSubview:text];
    }

    
    //4, 进度的曲线
    UIBezierPath *progressPath  = [UIBezierPath bezierPathWithArcCenter:self.view.center radius:120 startAngle:-M_PI endAngle:0 clockwise:YES];
    CAShapeLayer *progressLayer = [CAShapeLayer layer];
    self.progressLayer = progressLayer;
    progressLayer.lineWidth = 40.f;
    progressLayer.fillColor = [UIColor clearColor].CGColor;
    progressLayer.strokeColor = [UIColor colorWithRed:0.3054 green:0.698 blue:0.2075 alpha:0.21].CGColor;
    progressLayer.path = progressPath.CGPath;
    progressLayer.strokeStart = 0;
    progressLayer.strokeEnd = 0.5;
    [self.view.layer addSublayer:progressLayer];
    
}

- (UILabel *)speedLabel {
    if (!_speedLabel) {
        UILabel *speedLabel = [[UILabel alloc] initWithFrame:(CGRect){0, 0, 100, 100}];
        self.speedLabel = speedLabel;
        self.speedLabel.center = self.view.center;
        self.speedLabel.font = [UIFont boldSystemFontOfSize:30.0f];
        self.speedLabel.textAlignment = NSTextAlignmentCenter;
        self.speedLabel.textColor = [UIColor whiteColor];
    }
    return _speedLabel;
}


//默认计算半径135
- (CGPoint)calculateTextPositonWithArcCenter:(CGPoint)center
                                       Angle:(CGFloat)angel
{
    CGFloat x = 135 * cosf(angel);
    CGFloat y = 135 * sinf(angel);
    
    return CGPointMake(center.x + x, center.y - y);
}

//定时器事件
- (void)setSpeedProgress {
    NSInteger currentSpeed = arc4random_uniform(100);
    self.speedLabel.text = [NSString stringWithFormat:@"%zd", currentSpeed];
    [UIView animateWithDuration:0.8 animations:^{
        self.progressLayer.strokeEnd = 0.01 * currentSpeed;
    }];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
