//
//  ViewController.h
//  GGSpeedDial
//
//  Created by 高立发 on 2016/10/21.
//  Copyright © 2016年 GG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

